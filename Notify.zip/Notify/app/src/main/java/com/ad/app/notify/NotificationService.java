package com.ad.app.notify;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.IBinder;
import android.widget.RemoteViews;
import android.widget.Toast;

import androidx.annotation.Nullable;
import android.support.v4.media.app.NotificationCompat
import androidx.core.content.res.ResourcesCompat;

import java.util.Random;

public class NotificationService extends Service {

    private static int NOTIFICATION_ID;

    //TODO - SETTINGS - DISMISS NOTIFICATIONS AFTER SPECIFIC TIME (DEFAULT 24 HRS)
    //TODO - ADD TIME AFTER APP NAME
    //TODO - SETTINGS FOR PHONE NUMBER [OPTIONS - TAP TO COPY/ TAP TO OPEN KEYPAD]
    //TODO - OPEN EMAIL ADDRESS IN EMAIL APP

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        NOTIFICATION_ID = new Random().nextInt((1000 + 10000) + 1) + 1000;
        customNotification(intent.getStringExtra("message"));

        return super.onStartCommand(intent, flags, startId);
    }


    private void customNotification(String receivedText) {

        String channelId = getChannelId();
        String channelName = getChannelName();
        String trimmedText = receivedText.length() > 400 ?
                receivedText.substring(0, 400) + "..." :
                receivedText;


        RemoteViews contentView = new RemoteViews(getPackageName(), R.layout.layout_notification);
        contentView.setImageViewResource(R.id.image, R.mipmap.ic_launcher);
//        contentView.setTextViewText(R.id.txt_Body, trimmedText);


        if (new TextProcessor().isWebUrl(receivedText)) {
//            String title =  + " • " + new Utils().getCurrentTime() + " • " + "Tap to open link";
//            contentView.setTextViewText(R.id.txt_IntentAction, " • " + "Tap to open link");
            contentView.setTextColor(R.id.txt_Body, Color.parseColor("#0645AD"));
            contentView.setOnClickPendingIntent(R.id.linear_Container, getIntentAction(IntentProcessActivity.class, receivedText, "website"));

        } else if (new TextProcessor().isPhoneNumber(receivedText)) {
//            String title = getString(R.string.app_name) + " • " + new Utils().getCurrentTime() + " • " + "Tap to open dialer";
//            contentView.setTextViewText(R.id.txt_IntentAction, "Tap to open dialer");

            contentView.setOnClickPendingIntent(R.id.linear_Container, getIntentAction(IntentProcessActivity.class, receivedText, "dialer"));

        } else if (new TextProcessor().isValidEmail(receivedText)) {
//            String title = getString(R.string.app_name) + " • " + new Utils().getCurrentTime() + " • " + "Tap to open Gmail";
//            contentView.setTextViewText(R.id.txt_IntentAction, " • " + "Tap to open Gmail");
            contentView.setOnClickPendingIntent(R.id.linear_Container, getIntentAction(IntentProcessActivity.class, receivedText, "email"));

        } else {
//            String title = getString(R.string.app_name) + " • " + new Utils().getCurrentTime() + " • " + "Tap to copy";
//            contentView.setTextViewText(R.id.txt_IntentAction, " Tap to copy");
            contentView.setOnClickPendingIntent(R.id.linear_Container, getIntentAction(MainActivity.class, "null", ""));

        }

        NotificationCompat.Builder mBuilder;
        mBuilder = new NotificationCompat.Builder(this, channelId);
        mBuilder.setSmallIcon(R.mipmap.ic_new_launcher_round);
        mBuilder.setAutoCancel(false);
        mBuilder.setOngoing(true);
        mBuilder.setPriority(Notification.PRIORITY_HIGH);
        mBuilder.setBadgeIconType(NotificationCompat.BADGE_ICON_NONE);
        mBuilder.setSilent(true);
        mBuilder.setGroupSummary(true);
        mBuilder.setGroup(String.valueOf(NOTIFICATION_ID));
        mBuilder.build().flags = Notification.FLAG_NO_CLEAR | Notification.PRIORITY_HIGH;
        mBuilder.setVisibility(NotificationCompat.VISIBILITY_SECRET);
        mBuilder.setCustomBigContentView(contentView);
        mBuilder.setCustomContentView(contentView);

        mBuilder.setColor(getColor(R.color.color_StickyNote7));
        mBuilder.setColorized(true);

        mBuilder.setStyle(new NotificationCompat.DecoratedMediaCustomViewStyle());

        NotificationManager notificationManager;
        notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_HIGH);
            channel.enableVibration(false);
            channel.setLockscreenVisibility(Notification.VISIBILITY_SECRET);
            notificationManager.createNotificationChannel(channel);
            mBuilder.setChannelId(channelId);
        }

        notificationManager.notify(NOTIFICATION_ID, mBuilder.build());

        Toast.makeText(this, "Added to Notify", Toast.LENGTH_SHORT).show();
        stopSelf();
    }

    private RemoteViews getCustomRemoteView(){

        return null;
    }

    private PendingIntent getIntentAction(Class<?> redirectActivity, String text, String action) {

        // Creates an intent for clicking on notification-------------------------------------------
        Intent resultIntent = new Intent(this, redirectActivity);
        resultIntent.putExtra("action", action);
        resultIntent.putExtra("text", text);
        resultIntent.setAction(String.valueOf(NOTIFICATION_ID));

        TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);
        stackBuilder.addParentStack(MainActivity.class);
        stackBuilder.addNextIntent(resultIntent);
        return stackBuilder.getPendingIntent(0,
                PendingIntent.FLAG_IMMUTABLE);
    }

    private String getChannelId() {
        return "Test Channel Id";
    }

    private String getChannelName() {
        return "Test Channel Name";
    }

    private boolean isNotificationVisible(int id) {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent test = PendingIntent.getActivity(this, id, notificationIntent, PendingIntent.FLAG_NO_CREATE);
        return test != null;
    }


//    public void defaultNotification(String message) {
//        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
//
//        String channelId = getChannelId();
//        CharSequence channelName = getChannelName();
//
//        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(
//                this, getChannelId())
//                .setSmallIcon(R.drawable.ic_launcher_foreground)
////                .setContentTitle(requireContext().getString(R.string.app_name))
//                .setContentText(message)
//                .setOngoing(true).setWhen(0)
//                .setChannelId(getChannelId())
//                .setAutoCancel(false)
//                .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
//                .setTicker(message)
//                .setPriority(NotificationCompat.PRIORITY_MIN);
//
//        mBuilder.setContentIntent(getIntentAction(MainActivity.class));
//
//
//
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            NotificationChannel channel = new NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_HIGH);
//            channel.enableVibration(false);
//            channel.setShowBadge(false);
//            channel.setLockscreenVisibility(Notification.VISIBILITY_SECRET);
//            notificationManager.createNotificationChannel(channel);
//        }
//
//        notificationManager.notify(NOTIFICATION_ID, mBuilder.build());
//
//    }

}
