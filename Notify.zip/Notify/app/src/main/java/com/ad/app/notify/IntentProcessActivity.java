package com.ad.app.notify;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class IntentProcessActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String text = String.valueOf(getIntent().getStringExtra("text"));
        String action = getIntent().getStringExtra("action");

        if (action.equals("website")) {

            Intent intent = new TextProcessor().isYoutubeUrl(text) ?
                    new Intent(Intent.ACTION_VIEW, Uri.parse(new TextProcessor().getIdFromUrl(text))) :
                    new Intent(Intent.ACTION_VIEW, Uri.parse(text));

            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(Intent.createChooser(intent, "Choose browser"));


        } else if (action.equals("dialer")) {

            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:" + text));
            startActivity(intent);
        }


        finish();
    }





}
