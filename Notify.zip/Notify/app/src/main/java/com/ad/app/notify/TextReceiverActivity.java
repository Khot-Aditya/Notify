package com.ad.app.notify;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class TextReceiverActivity extends AppCompatActivity {

    //audio/mp4
    //audio/mpeg
    //application/pdf

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();
        CharSequence message = getIntent().getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT);

        if (Intent.ACTION_SEND.equals(action) && "text/plain".equals(type)) {
            Intent intent1 = new Intent(this, NotificationService.class);
            intent1.putExtra("message", intent.getStringExtra(Intent.EXTRA_TEXT));
            startService(intent1);
        }else if(message != null){
            Intent intent1 = new Intent(this, NotificationService.class);
            intent1.putExtra("message", message.toString());
            startService(intent1);
        }else{
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }

//        if (Intent.ACTION_SEND.equals(action) && "image/*".equals(type)) {
//
//        }

        finish();
    }
}